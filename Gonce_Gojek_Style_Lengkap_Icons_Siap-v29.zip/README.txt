GONCE — KATALOG PRODUK TANPA AUTHENTICATION
===========================================

PERUBAHAN
---------
- Nama yang tampil di aplikasi pengguna diganti menjadi Gonce.
- Login/Authentication Admin dihapus. Menu Admin langsung membuka Panel Admin.
- Tampilan, warna, katalog, kategori, banner, dan alur pemesanan dipertahankan.
- Panel Admin tidak lagi memanggil Supabase Authentication atau pemeriksaan sesi.
- Bisa menambahkan banyak toko; setiap toko dapat diedit dan memiliki logo sendiri.
- Produk dapat ditambahkan ke toko yang dipilih, lalu harga/stok/foto/kategorinya dapat diedit.
- Pencarian Admin untuk nama produk, kategori, harga, dan stok tersedia.
- Upload logo/foto menerima JPG, PNG, WEBP, dan format gambar yang dapat dibaca browser; otomatis dikonversi ke JPEG.
- Kategori dapat ditambahkan; kategori yang pernah dinonaktifkan dapat diaktifkan kembali.

LANGKAH PEMASANGAN
------------------
1. Cadangkan database Supabase terlebih dahulu.
2. Buka Supabase > SQL Editor > New query.
3. Salin seluruh isi supabase.sql dari ZIP ini lalu tekan Run.
4. Ganti index.html di GitHub dengan file dari ZIP ini.
5. Tunggu hosting selesai memperbarui situs, lalu refresh.
6. Tekan tombol Admin untuk membuka Panel Admin tanpa login.

PERINGATAN KEAMANAN PENTING
--------------------------
Karena Anda meminta tanpa Authentication, SQL memberikan hak perubahan data
kepada role anon. Artinya siapa pun yang mengetahui tautan aplikasi atau endpoint
Supabase dapat mengubah/menghapus produk, kategori, toko, banner, dan melihat
riwayat pesanan melalui akses database. Ini TIDAK aman untuk aplikasi publik.
Jangan menyimpan data sensitif. Jika ingin Panel Admin tetap tanpa login tetapi
terlindungi, diperlukan mekanisme keamanan lain di sisi server (bukan sekadar
menyembunyikan tombol atau halaman Admin).

Konfigurasi frontend tetap menggunakan Project URL dan publishable/anon key.
JANGAN pernah memasukkan service_role key ke index.html.


FITUR TAMPILAN PENGGUNA TERBARU
- Ride: formulir nama, lokasi GPS penjemputan, tujuan, catatan, dan kirim ke WhatsApp Admin.
- Food: menampilkan produk yang ditandai Rekomendasi oleh Admin.
- Mitra: menampilkan seluruh toko aktif; pilih toko untuk melihat katalog produknya.
- Nomor WhatsApp Ride diambil dari nomor WhatsApp toko yang pertama memiliki nomor aktif pada data toko.
- GPS memerlukan izin lokasi browser dan koneksi HTTPS. Pengguna dapat mengisi lokasi secara manual jika izin GPS tidak tersedia.


PEMBARUAN IKON LAYANAN GONCE
- Admin dapat mengganti gambar ikon Ride, Food, dan Mitra dari menu Ikon Layanan Pengguna.
- Pilih gambar dari galeri HP (JPG/PNG/WEBP), pratinjau akan tampil, lalu tekan Simpan Gambar Ikon.
- Gambar disimpan di tabel app_settings Supabase agar tampil sama pada semua perangkat.
- Jalankan supabase.sql versi terbaru satu kali di Supabase SQL Editor sebelum memakai fitur ini.
- Rekomendasi gambar: persegi 1:1, objek jelas, latar bersih, ukuran file wajar.


PEMBARUAN KELOLA PRODUK PER TOKO
- Admin dapat memilih Semua Toko atau satu toko tertentu pada bagian Kelola Produk.
- Pencarian produk mengikuti toko yang sedang dipilih.
- Tombol Kelola Produk tersedia pada setiap baris toko.
- Tambah Produk dari toko tertentu otomatis memilih toko tersebut.
- Saat Edit Produk, Admin dapat melihat dan mengganti toko produk melalui pilihan toko pada formulir.
- Tambah, edit nama, harga, stok, kategori, foto, dan toko produk disimpan pada tabel public.products.
- SQL tidak perlu diubah untuk fitur filter dan pengelolaan produk per toko; struktur products.store_id sudah digunakan.

PENGATURAN TARIF RIDE & PERHITUNGAN GPS
--------------------------------------
- Admin dapat mengatur Tarif Dasar, Tarif per Kilometer, dan Tarif Minimum pada bagian Pengaturan Tarif Ride.
- Pengaturan tarif disimpan bersama di tabel public.app_settings dengan key 'ride_fare'.
- Pengguna Ride memiliki tombol GPS Penjemputan dan GPS Tujuan secara terpisah.
- Setelah kedua titik GPS tersedia, aplikasi meminta jarak rute berkendara dari layanan OSRM/OpenStreetMap, lalu menghitung estimasi: tarif dasar + (jarak km x tarif per km), dengan batas tarif minimum.
- Estimasi jarak/rute membutuhkan internet, izin GPS, dan HTTPS. Jika layanan rute tidak tersedia, pesanan tetap dapat dikirim melalui WhatsApp untuk konfirmasi Admin, tetapi tarif tidak ditampilkan sebagai angka pasti.
- Tarif yang dikirim ke WhatsApp disebut estimasi; Admin/driver tetap mengonfirmasi harga akhir sesuai kondisi perjalanan.
- Tidak memerlukan perubahan SQL baru apabila database sudah memakai supabase.sql versi GONCE sebelumnya karena tabel app_settings sudah tersedia.


PENTING — PERBAIKAN GPS ANDROID
-------------------------------
- GPS browser memerlukan aplikasi dibuka melalui alamat website HTTPS.
- Jangan membuka index.html langsung dari File Manager, WhatsApp, atau arsip ZIP (alamat content:// atau file://); cara tersebut dapat memblokir izin lokasi.
- Publikasikan index.html ke hosting HTTPS (misalnya GitHub Pages), lalu buka link https://... menggunakan Chrome.
- Di Chrome Android, buka info/izin situs pada ikon di kiri alamat website, pilih Izin > Lokasi > Izinkan.
- Pastikan Pengaturan Android > Lokasi aktif dan izin lokasi untuk Chrome diizinkan.
- Jika izin pernah ditolak, ubah izin situs Chrome menjadi Izinkan lalu muat ulang halaman.
- Untuk mengambil GPS tujuan, pengguna harus berada di lokasi tujuan saat menekan tombol GPS Tujuan. Jika tidak, isi alamat tujuan secara manual; tarif GPS tidak dapat dihitung otomatis dari alamat teks.
- Jika lokasi tidak tersedia, kode kini menampilkan petunjuk berbeda untuk izin ditolak, posisi tidak tersedia, dan waktu habis.

PEMBARUAN TAMPILAN MITRA — LOGO TOKO 1:1
---------------------------------------
- Menu Mitra menampilkan semua toko aktif yang dikelola Admin.
- Logo setiap toko ditampilkan dalam bingkai persegi rasio 1:1 dengan object-fit contain agar logo tidak terpotong.
- Nama toko ditampilkan di bawah logo; deskripsi/alamat dihilangkan agar katalog lebih bersih.
- Toko yang belum memiliki logo menampilkan ikon toko pengganti.
- Ketuk logo/kartu toko untuk membuka produk dari toko tersebut saja.
- Pada halaman produk toko tersedia tombol “Semua Mitra” untuk kembali ke daftar toko.
- Tidak memerlukan perubahan SQL. Pastikan toko berstatus aktif dan logo sudah disimpan melalui Kelola Toko di Admin.


PEMBARUAN PETA RIDE DAN LOKASI TOKO
1. Ganti index.html pada GitHub dengan versi terbaru.
2. Buka Supabase > SQL Editor > New query.
3. Jalankan blok "MIGRASI LOKASI PETA TOKO GONCE" di bagian paling bawah supabase.sql.
   Jika ingin, blok migrasi saja cukup; jangan menjalankan ulang seluruh SQL lama.
4. Website harus dibuka melalui HTTPS agar GPS berfungsi.
5. Peta membutuhkan koneksi internet untuk memuat Leaflet dan tile OpenStreetMap.
6. Pada Ride, pengguna dapat mengetuk peta untuk memilih titik penjemputan dan tujuan, atau menggunakan GPS.
7. Pada Admin > Tambah/Edit Toko, ketuk peta untuk menyimpan titik lokasi toko atau gunakan GPS toko.

8. Checkout Food: Admin wajib mengisi lokasi toko. Pengguna memilih titik pengantaran pada peta atau GPS; ongkir dihitung dari lokasi toko ke titik pelanggan dengan tarif Ride yang sama.
9. SQL menambahkan kolom koordinat toko dan delivery_fee serta fungsi checkout_order_with_delivery. Jalankan blok migrasi dan fungsi baru di bagian akhir SQL sebelum memakai checkout Food baru.

File supabase_migration_peta_ongkir.sql adalah migrasi tambahan yang dijalankan di Supabase SQL Editor. Jalankan file ini satu kali; tidak menghapus toko, produk, atau pesanan yang sudah ada.


PEMBARUAN TERBARU - LOGO DAN FORMAT WHATSAPP
1. Logo kubus GONCE di header dipertahankan tetap; logo toko tidak lagi menggantinya secara otomatis.
2. Logo toko hanya tampil pada kartu toko di layanan Mitra dan pengelolaan toko Admin.
3. Ikon layanan Ride, Food, dan Mitra tetap dikelola terpisah melalui menu Ikon Layanan Pengguna.
4. Pesan WhatsApp Ride dipisah menjadi DATA PEMESAN, LOKASI PENJEMPUTAN, LOKASI TUJUAN, dan RINCIAN PERJALANAN. Link lokasi tidak lagi memiliki label ganda.
5. Pesan WhatsApp Food menambahkan nama toko, alamat toko, dan link Google Maps toko (jika koordinat toko sudah disimpan Admin).

Tidak ada perubahan SQL untuk pembaruan ini. Database yang sudah berjalan tidak perlu menjalankan SQL ulang.

PEMBARUAN TEMA DAN LOGO GONCE
=============================
- Tema aplikasi diperbarui menjadi hijau tua dan hijau lembut.
- Admin kini memiliki bagian "Logo Utama GONCE" yang terpisah dari ikon Ride/Food/Mitra dan logo masing-masing toko.
- Logo utama disimpan pada tabel app_settings dengan key brand_logo.
- File SQL tidak berubah. Tidak perlu menjalankan SQL ulang jika tabel app_settings dari instalasi sebelumnya sudah tersedia dan dapat dibaca/ditulis oleh anon sesuai kebijakan aplikasi saat ini.
- Jika tabel app_settings belum ada, jalankan supabase.sql hanya pada proyek database baru/kosong; jangan menjalankan ulang file setup penuh pada database lama.
- Setelah upload index.html ke GitHub Pages, buka Admin > Logo Utama GONCE, pilih gambar dari galeri, lalu tekan Simpan Logo GONCE.


PEMBARUAN TAMPILAN DETAIL TOKO — PRODUK SEPERTI GOFOOD
------------------------------------------------------
- Saat pengguna membuka menu Mitra lalu mengetuk salah satu toko, aplikasi
  membuka daftar produk khusus toko tersebut.
- Halaman detail menampilkan logo/nama toko di bagian atas.
- Produk ditampilkan dalam daftar horizontal: foto produk di sisi kanan,
  nama dan harga di sisi kiri, serta tombol "+ Tambah".
- Tombol keranjang tetap memakai fungsi keranjang dan checkout yang sudah ada.
- Tombol "← Semua Mitra" mengembalikan pengguna ke daftar toko.
- Tampilan katalog utama, Ride, Food, Admin, banner, warna, database, dan
  pengaturan lainnya tidak diubah.
- Tidak ada perubahan SQL. Cukup ganti index.html di GitHub dengan file terbaru
  dari ZIP ini. Database Supabase yang sekarang tidak perlu dijalankan ulang.
\n\nPEMBARUAN PEMISAHAN MITRA FOOD\n1. Jalankan file supabase_migration_jenis_mitra.sql satu kali di Supabase SQL Editor.\n2. Toko yang sudah ada otomatis tetap menjadi Mitra Toko.\n3. Buka Admin > Kelola Toko, edit toko makanan, lalu pilih Jenis Mitra: Mitra Food.\n4. Simpan. Toko tersebut akan tampil di halaman khusus Food dengan banner mandiri rasio 2:1.\n5. Toko jenis Mitra Toko tetap tampil di katalog utama. Tidak perlu menjalankan ulang supabase.sql.\n

## Banner khusus setiap Mitra Food
- Admin > Kelola Toko > Tambah/Edit Toko, pilih Jenis Mitra: Mitra Food.
- Unggah gambar pada kolom Banner Mitra Food (disarankan rasio 2:1) lalu Simpan Toko.
- Setiap toko Food menyimpan banner masing-masing; saat logonya dipilih, banner tampil di atas identitas toko dan daftar produknya.
- Untuk database yang sudah dipakai, jalankan sekali file `supabase_migration_banner_food.sql` di Supabase SQL Editor. Migrasi ini hanya menambah kolom `food_banner_url` dan tidak menghapus data lama.
